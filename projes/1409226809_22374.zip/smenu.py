from io import BytesIO
import discord, moviepy.editor
import asyncio, requests, random
from rich import print
import os

from pydub import AudioSegment
from PIL import Image, ImageDraw, ImageFilter
from moviepy.editor import ImageClip, CompositeVideoClip
from moviepy.editor import VideoFileClip, AudioFileClip

from config import lbeatsid, mainchannel, payrole
from ext.gifs_url import *
from ext.dtb import pub_beat, replike, get_lock, minus_limit

class SelectTag(discord.ui.View):

    def __init__(self, bot, ms1: discord.TextChannel, r, uid):
        super().__init__()
        self.bot = bot
        self.ms1 = ms1
        self.r = r
        self.uid = uid
    
    async def on_timeout(self):
        try:
            await self.ms1.delete()
            await self.r.delete()
            await replike(self.uid)
        except discord.errors.NotFound:
            print("[green] канал уже был удалён")

    @discord.ui.select(
        placeholder = "Выбери 1-3 тега", 
        min_values = 1, 
        max_values = 3, 
        options = [ 
            discord.SelectOption(
                label="Жесткая драмка",
                description="Настроение",
                emoji="#️⃣"
            ),
            discord.SelectOption(
                label="Грустненький",
                description="Настроение",
                emoji="#️⃣"
            ),
            discord.SelectOption(
                label="Вайбик",
                description="Настроение",
                emoji="#️⃣"
            ),
            discord.SelectOption(
                label="Gang",
                description="Настроение",
                emoji="#️⃣"
            ),
            discord.SelectOption(
                label="Агрессивный",
                description="Настроение",
                emoji="#️⃣"
            ),
            discord.SelectOption(
                label="Мягкий",
                description="Настроение",
                emoji="#️⃣"
            ),
            discord.SelectOption(
                label="Дорогой",
                description="Настроение",
                emoji="#️⃣"
            ),
            discord.SelectOption(
                label="Любовный",
                description="Настроение",
                emoji="#️⃣"
            ),
            discord.SelectOption(
                label="Бит с нуля",
                description="Настроение",
                emoji="#️⃣"
            ),
            discord.SelectOption(
                label="UK Drill",
                description="Тайп бит",
                emoji="#️⃣"
            ),
            discord.SelectOption(
                label="Detroit",
                description="Тайп бит",
                emoji="#️⃣"
            ),
            discord.SelectOption(
                label="Philly Drill",
                description="Тайп бит",
                emoji="#️⃣"
            ),
            discord.SelectOption(
                label="Trap",
                description="Тайп бит",
                emoji="#️⃣"
            ),
            discord.SelectOption(
                label="Sample",
                description="Тайп бит",
                emoji="#️⃣"
            ),
            discord.SelectOption(
                label="Phonk",
                description="Тайп бит",
                emoji="#️⃣"
            ),
            discord.SelectOption(
                label="4PF/OTF",
                description="Тайп бит",
                emoji="#️⃣"
            ),
            discord.SelectOption(
                label="Opium",
                description="Тайп бит",
                emoji="#️⃣"
            ),
            discord.SelectOption(
                label="New Jazz",
                description="Тайп бит",
                emoji="#️⃣"
            ),
            discord.SelectOption(
                label="Witch House",
                description="Тайп бит",
                emoji="#️⃣"
            ),
            discord.SelectOption(
                label="Jerk",
                description="Тайп бит",
                emoji="#️⃣"
            ),
            discord.SelectOption(
                label="New Jersey",
                description="Тайп бит",
                emoji="#️⃣"
            ),
            discord.SelectOption(
                label="Plugg",
                description="Тайп бит",
                emoji="#️⃣"
            ),
            discord.SelectOption(
                label="Pain",
                description="Тайп бит",
                emoji="#️⃣"
            ),
            discord.SelectOption(
                label="RnB",
                description="Тайп бит",
                emoji="#️⃣"
            ),
            discord.SelectOption(
                label="Другое",
                description="Тайп бит",
                emoji="#️⃣"
            )
        ]
    )
    async def select_callback(self, select, interaction: discord.Interaction):
        d = ""
        for i in select.values:
            if i == select.values[len(select.values)-1]:
                d = d+ f"#️⃣{i}"
            else:
                d = d+ f"#️⃣{i}, "

        embed = discord.Embed(
            color=0x2B2D31,
            description="- <a:uploading:1224783431255326780> **Шаг 2 / 3**\n> Выбери ролик на фон твоего бита \n> (по центру будет твоя аватарка в Discord)\n\n"
        )
        embed.set_author(name="Выбери ролик на фон твоего бита",
                          icon_url="https://message.style/cdn/images/85c5348fc574ceabba1f7f1b4635cb2d2bd505ee664ccfa0774333cc16e9a458.png")
      

        embed.add_field(name="", value=f"`{d}`", inline=False)
        embed.add_field(name=" ", inline=True, value="**⬅️ Предыдущий фон**")
        embed.add_field(name=" ", inline=True, value="**➡️ Следующий фон**")
        embed.set_image(url=back0)
        embed.set_footer(text="Mafia #1", icon_url="https://message.style/cdn/images/3e620ca9c6a4a672451edb2834c58c8b4d8682f3665fc28dd72bb8d142c65bba.png")
        

        await interaction.response.send_message(embed=embed, view=ChooseBack(d=d, bot=self.bot, ms1=self.ms1, r=self.r, user=interaction.user))
    




class ChooseBack(discord.ui.View):
    def __init__(self, d, bot: discord.Bot, ms1: discord.TextChannel, r, user: discord.Member):
        super().__init__()
        self.ms1 = ms1
        self.user = user
        self.r = r
        self.image_urls = [
            {"url": back0, "paid": False, "lock": 0},
            {"url": back1, "paid": False, "lock": 0},
            {"url": back2, "paid": False, "lock": 1},
            {"url": back3, "paid": True, "lock": 0},
            {"url": back4, "paid": True, "lock": 0},
            {"url": back5, "paid": True, "lock": 0},
            {"url": back6, "paid": True, "lock": 0},
            {"url": back7, "paid": True, "lock": 0},
            {"url": back8, "paid": True, "lock": 0}

        ]
        self.current_index = 0
        self.d = d
        self.bot=bot


    @discord.ui.button(style=discord.ButtonStyle.secondary, emoji="⬅️")
    async def back_back(self, button, interaction):
        self.current_index = (self.current_index - 1) % len(self.image_urls)
        await self.update_embed(interaction)






    @discord.ui.button(label="Выбрать", style=discord.ButtonStyle.success, emoji="✅", disabled=False)
    async def select_back(self, button, interaction: discord.Interaction):

        
        await interaction.respond("ᅠ")

        embed = discord.Embed(description="- <a:uploading:1224783431255326780> **Шаг 3 / 3**\n> Готово! Теперь просто **пришли мне бит в этот диалог в формате MP3 или WAV**\n\n",
                        color=3158064)
        embed.set_author(name="Финал! Теперь отправь свой бит", icon_url="https://message.style/cdn/images/85c5348fc574ceabba1f7f1b4635cb2d2bd505ee664ccfa0774333cc16e9a458.png")
        embed.set_image(url="https://message.style/cdn/images/5257e82ddbd03de7aa941741fbb370f496e3744f8a56d687155b8b7297f92a8c.png")
        embed.set_footer(text="Mafia #1", icon_url="https://message.style/cdn/images/3e620ca9c6a4a672451edb2834c58c8b4d8682f3665fc28dd72bb8d142c65bba.png")

        await self.ms1.send(embed=embed)

        

        def check(m):
            return m.author == interaction.user and m.attachments and m.channel.id == self.ms1.id

        try:
            message = await self.bot.wait_for('message', check=check, timeout=300.0)

        except asyncio.exceptions.TimeoutError:
            try:
                await interaction.delete_original_response()
                await interaction.followup.send("Время ожидания вышло" )
                await self.ms1.delete()
                await self.r.delete()
                return
            except discord.errors.NotFound:
                return
        except Exception as e:
            print(e)
            return

        
        
        attachment = message.attachments[0]
        if attachment.filename.endswith(('.mp3', '.wav')):
            if not await self.check_audio_duration(attachment):
                await self.ms1.send("💡 Длительность аудиофайла не должна превышать **3:23**, но не переживай, просто загрузи новый")
                await asyncio.sleep(20)
                await self.ms1.delete()
                await self.r.delete()
            else:

                embed = discord.Embed(description="- <a:3339_loading:1224825121735180288> **Загрузка**\n> Я начал обрабатывать твой ролик. Как только будет готово, он появится в канале <#1225425284765847622>. Примерное время ожидания: ~5-10 минут\n",
                                      color=3158064)
                embed.set_author(name="Обрабатываю", icon_url="https://message.style/cdn/images/85c5348fc574ceabba1f7f1b4635cb2d2bd505ee664ccfa0774333cc16e9a458.png")
                embed.set_footer(text="Mafia #1", icon_url="https://message.style/cdn/images/3e620ca9c6a4a672451edb2834c58c8b4d8682f3665fc28dd72bb8d142c65bba.png")




                await self.ms1.send(embed=embed)
                await self.overlay_audio_on_video(attachment, self.current_index, interaction, tags=self.d)

                e = discord.Embed(description="- <:ok:1172743098779050037> **Успешно**\n> Ролик обработан и опубликован в канал <#1225425284765847622>",
                                  color=3158064)
                e.set_author(name="Готово!", icon_url="https://message.style/cdn/images/0b31f8d8bbefe82b7051824312c5986ad89b4146d7474b8c6a8ff6a1b2ed100a.png")
                e.set_footer(text="Mafia #1", icon_url="https://message.style/cdn/images/3e620ca9c6a4a672451edb2834c58c8b4d8682f3665fc28dd72bb8d142c65bba.png")
                try:
                    await interaction.user.send(embed=e)
                except:
                    pass
                try:
                    await self.ms1.delete()
                    await self.r.delete()
                except discord.errors.NotFound:
                    print("[green] канал уже был удалён")
                
        else:
            await self.ms1.send("Неверный формат. Файл должен быть в формате Mp3 или WAV.")
            await asyncio.sleep(20)
            await self.ms1.delete()
            await self.r.delete()





    async def check_audio_duration(self, attachment):
        # Download the attachment to a temporary file
        # Note: This is a simplified example. In a real application, you should handle file downloads and temporary file management more robustly.
        temp_file_path = "./audio/"+ attachment.filename
        await attachment.save(temp_file_path)



        # Load the audio file
        audio = AudioSegment.from_file(temp_file_path)

        # Check the duration of the audio file
        max_duration_seconds = 3 * 60 + 23 # Maximum duration in seconds (3 minutes and 23 seconds)
        if len(audio) > max_duration_seconds * 1000: # pydub works in milliseconds
            return False # The audio file exceeds the maximum duration

        return True

    async def overlay_audio_on_video(self, attachment, index, ctx: discord.Interaction, tags):

        video_path = f"./video/{index}__.mp4"
        

        audio_path = "./audio/"+ attachment.filename
        

        
        final_video_path = f"finals/{attachment.id}.mp4"

        def process_video():
            video = VideoFileClip(video_path)
            audio = AudioFileClip(audio_path)
            video = video.subclip(0, audio.duration)
            final_video = video.set_audio(audio)
            final_video.write_videofile(final_video_path, codec='libx264', verbose=False, logger=None)
            return audio.duration

        audio_duration = await asyncio.get_event_loop().run_in_executor(None, process_video)

        ravap = await self.create_rounded_avatar(ctx.user.avatar.url, "./ravatars/", ctx.user.id)
        fpath = await self.overlay_avatar_on_video(f"finals/{attachment.id}.mp4", ravap, "./finals/finals/", ctx.user.id, audio_duration)




        chid = ctx.channel.id
        channel = self.bot.get_channel(lbeatsid)


        loadbeatbtn = discord.ui.View(
            discord.ui.Button(label="Загрузить бит", style=discord.ButtonStyle.link, url=mainchannel)
        )

        msg = await channel.send(f"`{tags}`/{ctx.user.mention}", file=discord.File(fpath), view=loadbeatbtn, silent=True)
        await minus_limit(ctx.user.id)
        c = await msg.create_thread(name="Комментарии", slowmode_delay=180)
        await c.send("<:ok:1172743098779050037> **Твой** комментарий = 2 <a:coin:1224788530006331412> **тебе** на баланс. Важно! ⚠️ От **3 и больше слов**. Спам удаляется автоматически")

        await msg.add_reaction("👍")
        await msg.add_reaction("👎")

        os.remove(ravap)
        os.remove(fpath)


        await pub_beat(author=ctx.user.id, msg=msg.id)
        return
        


    async def create_rounded_avatar(self, avatar_url, output_path, user):
        response = requests.get(avatar_url)
        img = Image.open(BytesIO(response.content))
        img = img.resize((330, 330), Image.ANTIALIAS)

        rad = 55

        circle = Image.new('L', (rad * 2, rad * 2), 0)
        draw = ImageDraw.Draw(circle)
        draw.ellipse((0, 0, rad * 2 - 1, rad * 2 - 1), fill=255)
        alpha = Image.new('L', img.size, 255)
        w, h = img.size
        alpha.paste(circle.crop((0, 0, rad, rad)), (0, 0))
        alpha.paste(circle.crop((0, rad, rad, rad * 2)), (0, h - rad))
        alpha.paste(circle.crop((rad, 0, rad * 2, rad)), (w - rad, 0))
        alpha.paste(circle.crop((rad, rad, rad * 2, rad * 2)), (w - rad, h - rad))
        img.putalpha(alpha)
        img.save(f"{output_path}{user}.png")
        return f"{output_path}{user}.png"




    # Функция для добавления аватарки в видео
    async def overlay_avatar_on_video(self, video_path, avatar_path, output_path, user, dur):
        def process_video():
            avatar_clip = ImageClip(avatar_path, duration=dur)
            video_clip = VideoFileClip(video_path)
            final_clip = CompositeVideoClip([video_clip, avatar_clip.set_position(('center', 0.13), relative=True)])
            final_clip.write_videofile(f"{output_path}{user}.mp4", codec='libx264', verbose=False, logger=None)

        await asyncio.get_event_loop().run_in_executor(None, process_video)

        return f"{output_path}{user}.mp4"






    @discord.ui.button(label="Отмена", style=discord.ButtonStyle.danger, emoji="⚠️")
    async def cancel(self, button, interaction: discord.Interaction):
        await replike(interaction.user.id)
        
        await interaction.respond("Ты отменил загрузку бита" )
        await self.ms1.delete()
        await self.r.delete()

    




    @discord.ui.button(style=discord.ButtonStyle.secondary, emoji="➡️")
    async def next_back(self, button, interaction):
        self.current_index = (self.current_index + 1) % len(self.image_urls)
        await self.update_embed(interaction)



    async def update_embed(self, interaction):

        is_paid = self.image_urls[self.current_index]["paid"]
        islock = self.image_urls[self.current_index]["lock"]
        required_role = discord.utils.get(interaction.guild.roles, name=payrole)
        has_required_role = required_role in self.user.roles
        if (is_paid and not has_required_role) or (islock >=1 and islock > await get_lock(interaction.user.id)):
            self.select_back.disabled = True
        elif not is_paid and islock == 0:
            self.select_back.disabled = False

        if is_paid and not has_required_role:
            embed = discord.Embed(title="🔒 `Фон закрыт, необходим статус «Мафия»`")

        elif islock >=1 and islock > await get_lock(interaction.user.id):
            embed = discord.Embed(title="🔒 `Фон закрыт, можно получить только из кейса`")
        else:
            embed = discord.Embed(color=0x2B2D31)

        embed.add_field(name="", value=f"`{self.d}`", inline=False)
        embed.add_field(name=" ", inline=True, value="**⬅️ Предыдущий фон**")
        embed.add_field(name=" ", inline=True, value="**➡️ Следующий фон**")
        embed.set_footer(text="Mafia #1", icon_url="https://message.style/cdn/images/3e620ca9c6a4a672451edb2834c58c8b4d8682f3665fc28dd72bb8d142c65bba.png")
        embed.set_image(url=self.image_urls[self.current_index]['url'])

        await interaction.response.edit_message(embed=embed, view=self)