from rich import print
from ext.dtb import *
from config import *

import discord
from discord.ext import commands, tasks


class RankBtn(discord.ui.View):

    def __init__(self):
        super().__init__()

    @discord.ui.button(label="Мой кабинет", style=discord.ButtonStyle.primary, emoji="💻")
    async def my_cabinet(self, button: discord.ui.Button, interaction: discord.Interaction):
        await interaction.response.send_message("Ваш кабинет ещё не реализован. Работа в процессе.", ephemeral=True)

    @discord.ui.button(label="Моё место", style=discord.ButtonStyle.primary, emoji="📊")
    async def checkrank(self, button, interaction: discord.Interaction):
        if await check_user(interaction.user.id):
            rank = await get_user_rank(interaction.user.id)
            like = await get_like(interaction.user.id)
            plike = await get_plike(interaction.user.id)
            await interaction.response.send_message(f"Вы находитесь на `{rank}` месте\nВаши лайки: `{like}`\nВы поставили лайков: `{plike}`", ephemeral=True, delete_after=60)
        else:
            await reg_user(interaction.user.id)
            await interaction.response.send_message(f"Вы находитесь на `последнем` месте\nВы ещё не получали лайки", ephemeral=True, delete_after=60)


class TUser(commands.Cog):

    def __init__(self, bot):
        super().__init__()
        self.bot = bot
        self.update_top_users.start()

    @tasks.loop(minutes=5)
    async def update_top_users(self):
        
        topusers = await get_top_users()

        txt = ""

        for user_id, likes, coins in topusers:

            user = await self.bot.fetch_user(user_id)
            txt += f"{user.mention} -  Лайки: `{likes}`👍 - Баланс: `{coins}`🪙\n"

            ch = self.bot.get_channel(statid)
            embed = discord.Embed(
                title="Топ битмейкеров и богачей сервера", description="Я, уточка в очках, могу показаться несерьёзной. Но это не так. В честь начала работы бота объявляю соревнование окуней!\n\n> Первые **3 места** 🏆, которые расположатся и укрепятся в топе на момент 30.04.2024 получат по **1 000** ₽. Мало ли это? Да. Лучше ли чем ничего? Возможно. Но кто осилит первую строчку?"
            )
            embed.add_field(name="", value=txt, inline=False)
            embed.set_image(url="https://media.discordapp.net/attachments/1222939398979457114/1227071483302641674/Component_23_4.png?ex=6627125f&is=66149d5f&hm=f22bbca908c1ab5e8748c0cf2c14a815f6d1500defcba1071b9c4da6560dbb78&=&format=webp&quality=lossless")

        if hasattr(self, "msgg"):
            if self.msgg is None:
                self.msgg = await ch.send(embed=embed, view=RankBtn())
            else:    
                await self.msgg.edit(embed=embed, view=RankBtn())
        else:
            self.msgg = await ch.send(embed=embed, view=RankBtn())

    @update_top_users.before_loop
    async def before_update_top_users(self):
        await self.bot.wait_until_ready()


def setup(bot):
    bot.add_cog(TUser(bot))