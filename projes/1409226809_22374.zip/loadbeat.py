import discord
from discord.ext import commands
from discord.commands import SlashCommandGroup
from discord import ApplicationContext

from rich import print

class LBbtn(discord.ui.View):

    @discord.ui.button(label="Загрузить бит", style=discord.ButtonStyle.primary, emoji="😎")
    async def button_callback(self, button, interaction):
        await interaction.response.send_message("жопа") # Send a message when the button is clicked



class LoadBeat(commands.Cog):
    def __init__(self, bot: discord.Bot) -> None:
        self.bot = bot
    
    
    @discord.slash_command()
    async def test(self, ctx: discord.ApplicationContext) -> None:
        btn = LBbtn()
        await ctx.respond("popa", view=btn)


def setup(bot: discord.Bot) -> None:
    bot.add_cog(LoadBeat(bot))
    print("[cyan]лодбит загружен")

