
import json


async def whatisrole(id: int) -> str:
    with open('roles.json', 'r', encoding='utf-8') as file:
        data = json.load(file)

        # Проход по всем элементам в данных
        for item in data:
            # Проверка, есть ли у элемента поле 'price' и равно ли оно целевой цене
            if 'id' in data[item] and data[item]['id'] == int(id):
                return data[item]


            

async def whatissub(name: str) -> str:
    with open('sub.json', 'r', encoding='utf-8') as file:
        data = json.load(file)


        # Проход по всем элементам в данных
        for item in data:
            # Проверка, есть ли у элемента поле 'price' и равно ли оно целевой цене
            if 'name' in data[item] and data[item]['name'] == name:
                return data[item]
