import sqlite3
from rich import print
import discord
from config import payrole, admins

db = sqlite3.connect("users.db")
sql = db.cursor()


async def createdb():
    sql.execute("""CREATE TABLE IF NOT EXISTS users (
                id TEXT,
                likes INT,
                coins INT,
                putlike INT,
                limits INT,
                back INT,
                admin INT
                )
    """)

    sql.execute("""CREATE TABLE IF NOT EXISTS beats (
                id INT PRIMARY KEY,
                author_id TEXT,
                msg_id TEXT

    )""")

    sql.execute("""CREATE TABLE IF NOT EXISTS refs (
                id TEXT
    )""")

    db.commit()



async def check_ref(id: int) -> bool:
    sql.execute(f"SELECT * FROM refs WHERE id= ?", (id,))
    if sql.fetchone() is None:
        return False
    else:
        return True

async def ins_ref(id: int) -> True:
    sql.execute("INSERT INTO refs (id) VALUES (?)", (id,))
    db.commit()
    return True




async def pub_beat(author: int, msg: int) -> True:
    sql.execute("INSERT INTO beats (author_id, msg_id) VALUES (?, ?)", (author, msg,))
    db.commit()
    return True

async def get_ath(msg_id: int) -> int:
    ath = sql.execute("SELECT author_id FROM beats WHERE msg_id= ?", (msg_id,)).fetchone()[0]
    return ath

async def add_ref(user: int) -> True:
    coins = sql.execute("SELECT coins FROM users WHERE id= ?", (user,)).fetchone()[0]
    sql.execute("UPDATE users SET coins= ? WHERE id= ?", (coins+50, user,))
    db.commit()
    return True


async def add_like(author: int) -> True:
    lks = sql.execute("SELECT likes FROM users WHERE id= ?", (author,)).fetchone()[0]
    sql.execute("UPDATE users SET likes= ? WHERE id= ?", (lks+1, author,))
    coins = sql.execute("SELECT coins FROM users WHERE id= ?", (author,)).fetchone()[0]
    sql.execute("UPDATE users SET coins= ? WHERE id= ?", (coins+5, author,))
    db.commit()
    return True

async def add_com(author: int) -> True:
    coins = sql.execute("SELECT coins FROM users WHERE id= ?", (author,)).fetchone()[0]
    sql.execute("UPDATE users SET coins= ? WHERE id= ?", (coins+2, author,))
    db.commit()
    return True

async def addplike(user: int) -> True:
    plks = sql.execute("SELECT putlike FROM users WHERE id= ?", (user,)).fetchone()[0]
    sql.execute("UPDATE users SET putlike= ? WHERE id= ?", (plks+1, user,))
    db.commit()

async def nullplike(user: int) -> True:
    sql.execute("UPDATE users SET putlike= ? WHERE id= ?", (0, user,))
    db.commit()

async def minus_plike(user: int) -> True:
    plike = sql.execute("SELECT putlike FROM users WHERE id= ?", (user,)).fetchone()[0]
    sql.execute("UPDATE users SET putlike= ? WHERE id= ?", (plike-5, user,))
    db.commit()


async def replike(user: int) -> True:
    plike = sql.execute("SELECT putlike FROM users WHERE id= ?", (user,)).fetchone()[0]
    sql.execute("UPDATE users SET putlike= ? WHERE id= ?", (plike+5, user,))
    db.commit()



async def check_user(id: int) -> bool:
    sql.execute(f"SELECT * FROM users WHERE id= ?", (id,))
    if sql.fetchone() is None:
        return False
    else:
        return True
    


async def reg_admin(id: int) -> True:
    sql.execute("INSERT INTO users VALUES (?, ?, ?, ?, ?, ?, ?)", (id, 200, 200000, 200, 10, 10, 10,))
    db.commit()

    print(f"[yellow]Зарегестрирован Админ {id}")

    return True



async def reg_user(id: int) -> True:
    if id in admins:
        sql.execute("INSERT INTO users VALUES (?, ?, ?, ?, ?, ?, ?)", (id, 200, 200000, 200, 10, 10, 10,))
    else:
        sql.execute("INSERT INTO users VALUES (?, ?, ?, ?, ?, ?, ?)", (id, 0, 0, 0, 2, 0, 0,))
    db.commit()

    print(f"[yellow]Зарегестрирован челик {id}")

    return True

async def can_like(id: int) -> bool:
    putlikes = sql.execute("SELECT putlike FROM users WHERE id= ?", (id,)).fetchone()[0]
    if putlikes >=5:
        return True
    elif putlikes <5:
        return False


async def get_bal(id: int) -> int:
    bal = sql.execute("SELECT coins FROM users WHERE id = ?", (id,)).fetchone()[0]
    return bal

async def get_like(id: int) -> int:
    like = sql.execute("SELECT likes FROM users WHERE id = ?", (id,)).fetchone()[0]
    return like

async def get_lock(id: int) -> int:
    lock = sql.execute("SELECT back FROM users WHERE id = ?", (id,)).fetchone()[0]
    return lock
async def get_plike(id: int) -> int:
    plike = sql.execute("SELECT putlike FROM users WHERE id = ?", (id,)).fetchone()[0]
    return plike


async def minus_bal(id: int, price: int) -> bool:
    bal = sql.execute("SELECT coins FROM users WHERE id = ?", (id,)).fetchone()[0]
    if bal >= price:
        sql.execute("UPDATE users SET coins= ? WHERE id= ?", (bal-price, id,))
        return True
    else:
        return False
    
async def plus_bal(id: int, price: int) -> bool:
    bal = sql.execute("SELECT coins FROM users WHERE id = ?", (id,)).fetchone()[0]
    sql.execute("UPDATE users SET coins= ? WHERE id= ?", (bal+price, id,))
    return True


async def unsetadm(user: int) -> True:
    sql.execute("UPDATE users SET admin= ? WHERE id= ?", (0, user,))
    db.commit()
    return True

async def setadm(user: int) -> True:
    sql.execute("UPDATE users SET admin= ? WHERE id= ?", (1, user,))
    db.commit()
    return True

async def unlockback1(user: int) -> True:
    sql.execute("UPDATE users SET back= ? WHERE id= ?", (1, user,))
    db.commit()
    return True


async def plus_limit(user: int) -> True:
    lim = sql.execute("SELECT limits FROM users WHERE id= ?", (user,)).fetchone()[0]
    sql.execute("UPDATE users SET limits= ? WHERE id= ?", (lim+1, user,))
    db.commit()

async def minus_limit(user: int) -> True:
    lim = sql.execute("SELECT limits FROM users WHERE id= ?", (user,)).fetchone()[0]
    sql.execute("UPDATE users SET limits= ? WHERE id= ?", (lim-1, user,))
    db.commit()

async def checklimit(user: int) -> bool:
    lim = sql.execute("SELECT limits FROM users WHERE id= ?", (user,)).fetchone()[0]
    if lim >= 1:
        return True
    if lim == 0:
        return False

async def checkadm(user: int) -> bool:
    adm = sql.execute("SELECT admin FROM users WHERE id= ?", (user,)).fetchone()[0]
    if adm >= 1:
        return True
    if adm == 0:
        return False




async def get_top_users():
    # Подключение к базе данных

    # Выполнение запроса для получения топ-10 пользователей по количеству лайков
    sql.execute("""
        SELECT id, likes, coins FROM users ORDER BY likes DESC LIMIT 10
    """)

    # Получение результатов запроса
    top_users = sql.fetchall()

    # Закрытие соединения с базой данных

    return top_users




async def get_user_rank(user_id: int) -> int:
    # Выполнение запроса для получения всех пользователей, отсортированных по количеству лайков
    sql.execute("""
        SELECT id, likes FROM users ORDER BY likes DESC
    """)
    all_users = sql.fetchall()

    # Преобразование списка в словарь для удобства поиска
    all_users_dict = {user[0]: user[1] for user in all_users}

    # Получение количества лайков текущего пользователя
    user_likes = sql.execute("SELECT likes FROM users WHERE id= ?", (user_id,)).fetchone()[0]

    # Определение ранга пользователя
    rank = 1
    for id, likes in all_users_dict.items():
        if likes > user_likes:
            rank += 1
        if id == user_id:
            break

    return rank







async def updatelimit(bot: discord.Bot):
    guild = bot.get_guild(1133927095563735050)
    sql.execute("SELECT * FROM users")
    allus = sql.fetchall()
    for user in allus:
        member = guild.get_member(user[0])
        has_premium_role = any(role.name == payrole for role in member.roles)
        if has_premium_role:
            sql.execute("UPDATE users SET limits= ? WHERE id= ?", (100, user[0],))
        else:
            sql.execute("UPDATE users SET limits= ? WHERE id= ?", (2, user[0],))
    db.commit()
    return True


async def updatelimuser(bot: discord.Bot, user: int) -> int:

    guild = bot.get_guild(1133927095563735050)
    member = guild.get_member(user)
    has_premium_role = any(role.name == payrole for role in member.roles)
    if has_premium_role:
        sql.execute("UPDATE users SET limits= ? WHERE id= ?", (100, user,))
        a = 100
    else:
        sql.execute("UPDATE users SET limits= ? WHERE id= ?", (2, user,))
        a = 2

    db.commit()
    return a