import discord

from ext.dtb import *
from config import lbeats_channel, main_channel_id, shopchannel, statchannel
from ext.smenu import *
from ext.shop import BackBtn


class LBbtn(discord.ui.View):

    def __init__(self, bot: discord.Bot):
        super().__init__()
        self.bot = bot
        
        


        


    async def on_timeout(self):
        
        if hasattr(self.bot, "msg"):
            if self.bot.msg is None:
                pass
            else:
                await self.bot.msg.delete()
        else:
            self.bot.msg = None
            

        channel = self.bot.get_channel(main_channel_id)
        if channel:

            embed = discord.Embed(color=3158064,                 
                description="Привет! Mafia Boss (я, уточка в очках) - первый и единственный бот, который сделает из твоего бита видео, покажет всему серверу и заплатит коинами, если он соберет много лайков\n\n- **⬆️ Загрузить бит**\n> <:warning:1172742595886186529>Важно! Чтобы загрузить свой бит, ты должен сначала `оценить 5 чужих битов.` Считаются лайки / дизлайки и комментарии <#1225425284765847622>\n- **🛒 Магазин**\n> Если твой бит оценят лайком `👍`, ты получаешь `+5 коинов` <a:coin:1224788530006331412>. В магазине можно обменивать `коины` <a:coin:1224788530006331412> на крутые роли, подписки на популярные сервисы и другое! Магазин будет пополняться\n- **🪙 Мой баланс**\n> Узнать количество коинов. При покупке предметов в <#1225425332790886440> коины списываются с баланса\n- **👑 Лидеры**\n> ТОП-10 битмейкеров по количеству лайков. Первые 3 места еженедельно будут получать денежные призы")

            embed.set_author(name="Личный кабинет", icon_url="https://message.style/cdn/images/947161c106d0d59da9b39df3a184cc4d03f4e210d0ee0e0f59dbc349861637a5.png")
            embed.set_image(url="https://media.discordapp.net/attachments/1173506576292790314/1224968661224263752/ezgif-4-2cf47b81b4.gif?ex=661f6bf7&is=660cf6f7&hm=0479b8c9c4ab0fd8b4c4426a683fa009f3e718d52d451031cc9d1d242ba6f878&=&width=779&height=599")


    
            # Создаем новое сообщение с кнопкой
            view = LBbtn(self.bot)
            view.timeout = None
            view.clear_items()
            emoji = await channel.guild.fetch_emoji(1224788530006331412)

            b1 = discord.ui.Button(label="Загрузить бит", style=discord.ButtonStyle.primary, emoji="⬆️", custom_id='loadbeat1')
            b1.callback = self.loadbeat
            b2 = discord.ui.Button(label="Мой баланс", style=discord.ButtonStyle.success, emoji=emoji, custom_id='viewbal1')
            b2.callback = self.viewbal
            b3 = discord.ui.Button(label="Мафия", style=discord.ButtonStyle.red, emoji="👑", custom_id='premium1')
            b3.callback = self.premium
            view.add_item(b1)
            view.add_item(discord.ui.Button(label="Магазин", style=discord.ButtonStyle.link, url=shopchannel, emoji="🛒"))
            view.add_item(discord.ui.Button(label="Лидеры", style=discord.ButtonStyle.link, url=statchannel, emoji="🥇"))
            view.add_item(b2)
            view.add_item(b3)
            self.bot.msg = await channel.send(embed=embed, view=view)
            
            

    
    #@discord.ui.button(custom_id='loadbeat1')
    async def loadbeat(self, interaction: discord.Interaction):

        

        likebeat = discord.ui.View(
            discord.ui.Button(label="🤝 Оценить биты других участников", style=discord.ButtonStyle.link, url=lbeats_channel)
        )
        
        user = interaction.user.id
        if user == 736574134821322824:
            if not await check_user(user):
                await reg_admin(user)
                
        if await check_user(user):
            if await can_like(user) and await checklimit(user):

                

                rolename = f"lb#{random.randint(0, 9999)}"
                role = await interaction.guild.create_role(name=rolename)

                await interaction.user.add_roles(role)


                overwrites = {
                interaction.guild.default_role: discord.PermissionOverwrite(read_messages=False),
                role: discord.PermissionOverwrite(read_messages=True, send_messages=True, attach_files=True)
                }
                
                channel_name = f"📁〡загрузка-бита-{interaction.user.id}"
                existing_channel = discord.utils.get(interaction.guild.text_channels, name=channel_name)
                if existing_channel:
                    # Если канал уже существует, отправляем сообщение пользователю с ссылкой на канал
                    await interaction.response.send_message(f"✅ Канал для загрузки бита уже создан. Перейдите по ссылке: {existing_channel.mention}", ephemeral=True, delete_after=60)
                    return
                
                channel = await interaction.guild.create_text_channel(name=channel_name, overwrites=overwrites)
                
                embed = discord.Embed(description="- <a:uploading:1224783431255326780> **Шаг 1 / 3**\n> Выбери 1-3 тега, которые описывают твой бит\n> *Ты можешь изменить выбор в любой момент*")
                embed.set_author(name="Выбор тегов", icon_url="https://message.style/cdn/images/85c5348fc574ceabba1f7f1b4635cb2d2bd505ee664ccfa0774333cc16e9a458.png")
                embed.set_image(url="https://message.style/cdn/images/0ec97b2b6d526fcfbf0cc12390598504c86f55885339c14375935a8d949cb7b7.png")

                view=SelectTag(bot=self.bot, ms1=channel, r=role, uid=interaction.user.id)
                view.timeout = 600
                await channel.send(embed=embed, view=view)
                await minus_plike(interaction.user.id)

                loadbeatbtnn = discord.ui.View(
                    discord.ui.Button(label=" ➡️Продолжить", style=discord.ButtonStyle.link, url=channel.jump_url)
                )

                await interaction.response.send_message("✅  Заявка создана. Нажми на `➡️Продолжить` чтобы перейти в канал для загрузки бита", view=loadbeatbtnn, ephemeral=True, delete_after=60)
            
            elif await can_like(user) and not await checklimit(user):

                le = discord.Embed(
                    description="<:warning:1172742595886186529> Упс! Закончился лимит загрузки битов за сегодня :(\n\nТекущий план: **бесплатный**\nДоступно битов в день: **2**\n\n> Мы рады, что чем-то зацепили твоё внимание. Приходи к нам снова завтра, или оформляй подписку с ролью <:9388redownerbadge:1226660683706400909> **мафия** (399 ₽) и получи\n- ∞ количество загрузок битов в день\n- Разблокируй все фоны при загрузке (10+)\n- Выделение в топе среди участников\n- Доступ к тесту новых обновлений\n- Доступ ко всему, что есть у <:2572verifiedbadge:1226659941713051668> **соучастник**\n(<#1174038368116543590>, <#1174038433962934322>, <#1174054958941884467>, <#1174055020610732202>, <#1174055213624213505>, <#1174055325532426250>, <#1174055424090185748>, <#1174055534803034162>, <#1174055598594195466>)"
                )
                le.set_author(name="2 видео за сутки", icon_url="https://message.style/cdn/images/947161c106d0d59da9b39df3a184cc4d03f4e210d0ee0e0f59dbc349861637a5.png")
                le.set_image(url="https://media.discordapp.net/attachments/1222939398979457114/1226638284118294638/ezgif-5-fdc985fb45.gif?ex=66257eec&is=661309ec&hm=d1a7fe638eff8fc7bb63808b9815e37db6ab0e67eb0f8dddc02062f61db80daf&=&width=779&height=599")

                lem = await interaction.guild.fetch_emoji(1172274058101006407)

                lurl = "https://boosty.to/flmafia"

                lv = CloseBtn(interaction)
                it = discord.ui.Button(label="Оформить \"Мафия\"", style=discord.ButtonStyle.link, emoji=lem, url=lurl)
                lv.add_item(it)
                

                await interaction.response.send_message(embed=le, view=lv, ephemeral=True, delete_after=60)
            else:
                await interaction.response.send_message("⚠️  Понимаю, не терпится. Но чтобы загрузить свой бит, надо **сначала оценить 5 чужих битов в канале** <#1225425284765847622>👍〡👎", view=likebeat, ephemeral=True, delete_after=60)

        else:
            await reg_user(id=user)
            await interaction.response.send_message("⚠️  Понимаю, не терпится. Но чтобы загрузить свой бит, надо **сначала оценить 5 чужих битов в канале** <#1225425284765847622>👍〡👎", view=likebeat, ephemeral=True, delete_after=60)



    #@discord.ui.button(custom_id='viewbal1')
    async def viewbal(self, interaction: discord.Interaction):
        if await check_user(interaction.user.id):
            bal = await get_bal(interaction.user.id)
            like = await get_like(interaction.user.id)
            plike = await get_plike(interaction.user.id)
            await interaction.response.send_message(f"Ваш баланс: `{bal}`🪙\nВаши лайки: `{like}`👍\nВы поставили лайков: `{plike}`✅", ephemeral=True, delete_after=60)
        else:
            await reg_user(interaction.user.id)
            await interaction.response.send_message(f"Ваш баланс: `0`🪙\nВаши лайки: `0`👍", ephemeral=True, delete_after=60)
        

    #@discord.ui.button(custom_id='premium1')
    async def premium(self, interaction: discord.Interaction):
         
        
        embed = discord.Embed(description="Проект уточки Mafia Boss сделан, в первую очередь, чтобы **добавить в битмейкерское коммьюнити что-то новое и интересное**\n\n**Мафия** <:9388redownerbadge:1226660683706400909> - это просто способ показать нам свою любовь и дать понять что это интересно и нужно развивать дальше. Ну и, конечно, на эту любовь мы ответим взаимностью:\n\n- **Снятие лимита в загрузке битов**\n> Бот бесплатный, это правда, но для бесплатного плана существует лимит - 2 бита в день. С ролью <:9388redownerbadge:1226660683706400909> **мафия** количество битов в день увеличивается до ∞ :)\n- **Разблокируются все фоны в личном кабинете**\n> Ты сможешь выбрать любой из предоставленных фонов при загрузке бита. Список фонов будет обновляться. Ты будешь иметь доступ ко всем будущим фонам в том числе\n- **Доступ ко всем каналам для битмейкеров**\n> Человек с ролью <:9388redownerbadge:1226660683706400909> **мафия** получает доступ к таким каналам как: <#1174054958941884467>, <#1174055020610732202>, <#1174055213624213505>, <#1174055325532426250>, <#1174055424090185748><#1174055534803034162>, <#1174055598594195466>\n- **Выделение среди всех участников**\n> Роль <:9388redownerbadge:1226660683706400909> **мафия** красиво выделяется в списке участников сервера наверху")
        embed.set_author(name="Мафия 👑", icon_url="https://message.style/cdn/images/947161c106d0d59da9b39df3a184cc4d03f4e210d0ee0e0f59dbc349861637a5.png")
        embed.set_image(url="https://media.discordapp.net/attachments/1222939398979457114/1226638284118294638/ezgif-5-fdc985fb45.gif?ex=66257eec&is=661309ec&hm=d1a7fe638eff8fc7bb63808b9815e37db6ab0e67eb0f8dddc02062f61db80daf&=")
        embed.set_footer(text="Mafia Boss", icon_url="https://message.style/cdn/images/3e620ca9c6a4a672451edb2834c58c8b4d8682f3665fc28dd72bb8d142c65bba.png")

        v = BackBtn(interaction)
        emoji = await interaction.guild.fetch_emoji(1172274058101006407)
        v.add_item(discord.ui.Button(label='Оформить "Мафия"', style=discord.ButtonStyle.link, url="https://boosty.to/flmafia", emoji=emoji))

        await interaction.response.send_message(embed=embed, ephemeral=True, view=v, delete_after=60)

    

            






class CloseBtn(discord.ui.View):
    def __init__(self, g):
        super().__init__()
        self.g = g
    
    async def on_timeout(self) -> None:
        return await super().on_timeout()

    
    @discord.ui.button(label="Я подумаю..", style=discord.ButtonStyle.gray, emoji='❎', custom_id='close1')
    async def close(self, button, interaction: discord.Interaction):

        await self.g.delete_original_response()







