from discord.ui.item import Item
from rich import print
from ext.dtb import *
from ext.what import *
from config import *
from caseroles import *
import random

import discord, asyncio, json
from discord.ext import commands



import discord

class Paginator(discord.ui.View):
    def __init__(self, roles_data, emojis: dict, bot, ctx: discord.Interaction, items_per_page=6):
        super().__init__()
        self.roles_data = roles_data
        self.emojis = emojis
        self.bot = bot
        self.ctx = ctx
        self.current_page = 0
        self.items_per_page = items_per_page
        self.max_pages = 4


    async def update_embed(self):

        if self.current_page ==0:
            embed = discord.Embed(
                description="Некоторые роли из магазина **со временем исчезнут и никогда больше не появятся**. Они помечены звездочкой* и лимитированы\n\n- <:pngwing:1172688623691386981> ``𝐅𝐋 𝐒𝐓𝐔𝐃𝐈𝐎`` — 111 <a:coin:1224788530006331412>\n- <:big_blush:1172407318747549736> ``ошмёток майонеза`` — 250 <a:coin:1224788530006331412>\n-  <:4571heartdamage3:1225155350307667998> ``ʟᴏS̶vᴇʀ`` — 333 <a:coin:1224788530006331412>\n-  <a:uzigold:1174188153226137630> ``𝐭𝐫𝐮𝐬𝐭𝐞𝐝`` — 600 <a:coin:1224788530006331412>\n-  <a:4955uziyee:1161072604380151968> ``Верный*`` — 600 <a:coin:1224788530006331412>\n-   <:bless:1225154820168486963> ``ʙʟᴇꜱꜱᴇᴅ`` — 1 777 <a:coin:1224788530006331412>"
            )
            embed.set_author(name="Роли (страница 1)", icon_url="https://message.style/cdn/images/947161c106d0d59da9b39df3a184cc4d03f4e210d0ee0e0f59dbc349861637a5.png")
            embed.set_image(url="https://message.style/cdn/images/ce7d6b623e9867f0bd7ee94a8f1fd6322e6db426bbc0f3bb834fcd2d5e4f60f4.png")
            embed.add_field(value="<:leftarrow_2b05fe0f:1226797088608878592> Предыдущая страница", inline=True, name=" ")
            embed.add_field(value="<:rightarrow_27a1fe0f:1226797078437691443> Следующая страница", inline=True, name=" ")
            embed.set_footer(text="Mafia Boss", icon_url="https://message.style/cdn/images/3e620ca9c6a4a672451edb2834c58c8b4d8682f3665fc28dd72bb8d142c65bba.png")
        
        elif self.current_page == 1:
            embed = discord.Embed(
                description="-   <:portrait:1225154848497074248> ``he/him/pudge*`` — 3 000 <a:coin:1224788530006331412>\n-   <:gang:1225155007247028330> ``𝖌𝖆𝖓𝖌`` — 4 000 <a:coin:1224788530006331412>\n-    <:__:1225160241730162822> ``роджер gang*`` — 7 777 <a:coin:1224788530006331412>\n-    <:S4LvB1o7gnnobackground1:1225154723716399136> ``𝖈𝖍𝖗𝖔𝖒𝖊 𝖍𝖊𝖆𝖗𝖙𝖘`` — 10 000 <a:coin:1224788530006331412>\n-   ⚠️ ``пользователь слит в подслушано астрахань`` — 15 000 <a:coin:1224788530006331412>\n-  <:6867sadkitty:1226768927871209493> ``сипсы с чыром`` — 20 000 <a:coin:1224788530006331412>"
            )
            embed.set_author(name="Роли (страница 2)", icon_url="https://message.style/cdn/images/947161c106d0d59da9b39df3a184cc4d03f4e210d0ee0e0f59dbc349861637a5.png")
            embed.set_image(url="https://message.style/cdn/images/ce7d6b623e9867f0bd7ee94a8f1fd6322e6db426bbc0f3bb834fcd2d5e4f60f4.png")
            embed.add_field(value="<:leftarrow_2b05fe0f:1226797088608878592> Предыдущая страница", inline=True, name=" ")
            embed.add_field(value="<:rightarrow_27a1fe0f:1226797078437691443> Следующая страница", inline=True, name=" ")
            embed.set_footer(text="Mafia Boss", icon_url="https://message.style/cdn/images/3e620ca9c6a4a672451edb2834c58c8b4d8682f3665fc28dd72bb8d142c65bba.png")
        
        elif self.current_page == 2:
            embed = discord.Embed(
                description="-  <a:rainbowsheep:1174185134384222238> ``𝟛𝟛𝟛𝟛𝟛`` — 33 333 <a:coin:1224788530006331412>\n- <:deserteagle:1226766850927493231> ``𝔬𝔬𝔱𝔢𝔯`` — 45 000 <a:coin:1224788530006331412>\n- <:7291hkface:1226765633732218901> ``я аблетонщица, вопросы?*`` — 55 000 <a:coin:1224788530006331412>\n- <a:kermitak47:1226766940756770828> ``я ненормальный, если честно`` — 55 000 <a:coin:1224788530006331412>\n- <a:7548chromecross:1226762794896982056> ``keep God first`` — 70 000 <a:coin:1224788530006331412>\n- <:5737w:1226763091027693628> ``𝕎*`` — 70 000 <a:coin:1224788530006331412>"
            )
            embed.set_author(name="Роли (страница 3)", icon_url="https://message.style/cdn/images/947161c106d0d59da9b39df3a184cc4d03f4e210d0ee0e0f59dbc349861637a5.png")
            embed.set_image(url="https://message.style/cdn/images/ce7d6b623e9867f0bd7ee94a8f1fd6322e6db426bbc0f3bb834fcd2d5e4f60f4.png")
            embed.add_field(value="<:leftarrow_2b05fe0f:1226797088608878592> Предыдущая страница", inline=True, name=" ")
            embed.add_field(value="<:rightarrow_27a1fe0f:1226797078437691443> Следующая страница", inline=True, name=" ")
            embed.set_footer(text="Mafia Boss", icon_url="https://message.style/cdn/images/3e620ca9c6a4a672451edb2834c58c8b4d8682f3665fc28dd72bb8d142c65bba.png")
        
        elif self.current_page == 3:
            embed = discord.Embed(
                description="-  <:roblox:1226768195159986226> ``roblox enjoyer`` — 100 000 <a:coin:1224788530006331412>\n- <:7525angelwings:1226765707359027271> ``𝖕𝖗𝖔𝖙𝖊𝖈𝖙𝖊𝖉`` — 100 000 <a:coin:1224788530006331412>\n- <:yasno:1155814580572921896> ``биты метро бумина так себе`` — 150 000 <a:coin:1224788530006331412>\n- <:9838_proteccbun:1226769324761682111> ``откуда у меня эта роль*`` — 150 000 <a:coin:1224788530006331412>\n- <:6212pixelnumberzero:1226713738493689938> ``获得这个角色的第一个是五千卢布`` — 333 333 <a:coin:1224788530006331412>\n- <a:8494potatotriggered:1225155091456200874> ``𝕸𝖆𝖋𝖎𝖆 𝕭𝖔𝖘𝖘`` — 500 000 <a:coin:1224788530006331412>"
            )
            embed.set_author(name="Роли (страница 4)", icon_url="https://message.style/cdn/images/947161c106d0d59da9b39df3a184cc4d03f4e210d0ee0e0f59dbc349861637a5.png")
            embed.set_image(url="https://message.style/cdn/images/ce7d6b623e9867f0bd7ee94a8f1fd6322e6db426bbc0f3bb834fcd2d5e4f60f4.png")
            embed.add_field(value="<:leftarrow_2b05fe0f:1226797088608878592> Предыдущая страница", inline=True, name=" ")
            embed.add_field(value="<:rightarrow_27a1fe0f:1226797078437691443> Следующая страница", inline=True, name=" ")
            embed.set_footer(text="Mafia Boss", icon_url="https://message.style/cdn/images/3e620ca9c6a4a672451edb2834c58c8b4d8682f3665fc28dd72bb8d142c65bba.png")
        


        start = self.current_page * self.items_per_page
        end = start + self.items_per_page
        for i in range(start, end):
            if i >= len(self.roles_data):
                break
            role, role_data = list(self.roles_data.items())[i]
            emoji = self.emojis.get(role)
            description = f"{role_data['desc']}" if emoji else role_data['desc']

        
        current_page_roles = dict(list(self.roles_data.items())[start:end])
        for item in self.children:
            if  hasattr(item, 'custom_id') and item.custom_id == "Selecter":

                self.remove_item(item)
                break

        role_select = RoleSelect(current_page_roles, self.emojis, self.bot, self.ctx)
        self.add_item(role_select)
    
        return embed

    @discord.ui.button(style=discord.ButtonStyle.primary, label="⬅️")
    async def previous_page(self, button: discord.Button, interaction: discord.Interaction):
        if self.current_page > 0:
            self.current_page -= 1
            embed = await self.update_embed()
            await interaction.response.edit_message(embed=embed, view=self)
        else:
            self.current_page = 3
            embed = await self.update_embed()
            await interaction.response.edit_message(embed=embed, view=self)

    @discord.ui.button(style=discord.ButtonStyle.primary, label="ㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤ", disabled=True)
    async def lochbutton(self, button: discord.Button, interaction: discord.Interaction):
        pass

    @discord.ui.button(style=discord.ButtonStyle.primary, label="➡️")
    async def next_page(self, button: discord.Button, interaction: discord.Interaction):
        if self.current_page < self.max_pages - 1:
            self.current_page += 1
            embed = await self.update_embed()
            await interaction.response.edit_message(embed=embed, view=self)
        else:
            self.current_page = 0
            embed = await self.update_embed()
            await interaction.response.edit_message(embed=embed, view=self)













class RoleSelect2(discord.ui.View):
    def __init__(self, emojis: dict, bot, ctx: discord.Interaction):
        super().__init__()
        with open('roles.json', 'r', encoding='utf-8') as file:
            roles_data = json.load(file)
            self.add_item(RoleSelect(roles_data, emojis, bot, ctx))

class RoleSelect(discord.ui.Select):
    def __init__(self, roles_data, emojis: dict, bot, ctx: discord.Interaction):
        self.ctx = ctx
        self.emojis = emojis
        self.bot = bot
        self.roles_data = roles_data
        options = []
        for role, role_data in roles_data.items():
            emoji = emojis.get(role)
            description = f"{role_data['desc']}" if emoji else role_data['desc']
            options.append(discord.SelectOption(label=role, value=str(role_data['id']), description=description, emoji=emoji))
        super().__init__(placeholder='Выбери роль', min_values=1, max_values=1, options=options, custom_id="Selecter")


    async def callback(self, interaction: discord.Interaction):
        rid = self.values[0]

        obj = await whatisrole(rid)

        role_id = int(self.values[0])
        role = interaction.guild.get_role(role_id)

        

        btnn = AcceptBtn(bot=self.bot, price=obj['price'], tovar=obj['name'], isrole=True, rid=rid, ctx=interaction)

        await self.ctx.delete_original_response()
        await interaction.response.send_message(f"Ты уверен, что хочешь купить `{obj['name']}`?", ephemeral=True, view=btnn, delete_after=60)







































class SubSelect2(discord.ui.View):
    def __init__(self, emojis: dict, bot, ctx: discord.Interaction):
        super().__init__()
        with open('sub.json', 'r', encoding='utf-8') as file:
            roles_data = json.load(file)
            self.add_item(SubrSelect(roles_data, emojis, bot, ctx))

class SubrSelect(discord.ui.Select):
    def __init__(self, roles_data, emojis: dict, bot, ctx: discord.Interaction):
        self.ctx = ctx
        self.bot = bot
        options = []
        for role, role_data in roles_data.items():
            emoji = emojis.get(role)
            description = f"{role_data['desc']}" if emoji else role_data['desc']
            options.append(discord.SelectOption(label=role, value=str(role_data['name']), description=description, emoji=emoji))
        super().__init__(placeholder='Что ты хочешь купить?', min_values=1, max_values=1, options=options)
    
    
    
    async def callback(self, interaction: discord.Interaction):

        tovar = self.values[0]


        obj = await whatissub(tovar)


        





        btnn = AcceptBtn(bot=self.bot, price=obj['price'], tovar=tovar, isrole=False, ctx=interaction)
        
        await self.ctx.delete_original_response()
        await interaction.response.send_message(f"Ты уверен, что хочешь купить `{tovar}`?", ephemeral=True, view=btnn, delete_after=60)

















class CatBtn(discord.ui.View):
    def __init__(self, ctx: discord.Interaction, em, em2, g: discord.Interaction, bot):
        super().__init__()
        self.clear_items()
        self.bot = bot
        self.g = g
        
        it = discord.ui.Button(label="Закрыть", style=discord.ButtonStyle.gray, emoji='❎')
        it.callback = self.close
        self.add_item(it)
        it1 = discord.ui.Button(label="Роли", style=discord.ButtonStyle.primary, emoji=em)
        it1.callback = self.showroles
        self.add_item(it1)
        
        it2 = discord.ui.Button(label="Подписки на сервисы и другое", style=discord.ButtonStyle.primary, emoji=em2)
        it2.callback = self.showosubs
        self.add_item(it2)

        it3 = discord.ui.Button(label="Кейсы", style=discord.ButtonStyle.primary, emoji="📦")
        it3.callback = self.cases
        self.add_item(it3)



    async def cases(self, interaction: discord.Interaction):
        
        embed = discord.Embed(
        description="Кейс **содержит:**\n\n<:veryrarenew:1226398297636208710>Подписка ``Spotify Individual (месяц)`` <:2320spotify:1225150214134956083>\n<:veryrarenew:1226398297636208710>Подписка ``Telegram Premium (месяц)`` <:9739telegram:1225164964801810523>\n<:veryrarenew:1226398297636208710>Подписка ``Discord Nitro (месяц)`` <:7841boostingseven:1161071349784129677>\n<:veryrarenew:1226398297636208710>Уникальный ``фон для бита`` <:1219check:1224825131101061180>  [если есть = 1 000]\n<:veryrarenew:1226398297636208710>Роль ``𝟛𝟛𝟛𝟛𝟛`` <a:rainbowsheep:1174185134384222238> [если есть = 1 000]\n<:veryrarenew:1226398297636208710>Скидка ``25% на Мафия`` <:9388redownerbadge:1226660683706400909>\n<:veryrarenew:1226398297636208710>Коины ``1 500`` <a:coin:1224788530006331412>\n<:mid:1226398298957418536>Коины ``499`` <a:coin:1224788530006331412>\n<:mid:1226398298957418536>Роль ``𝖌𝖆𝖓𝖌`` <:gang:1225155007247028330> [если есть = 150]\n<:mid:1226398298957418536>Роль ``ʙʟᴇꜱꜱᴇᴅ`` <:bless:1225154820168486963> [если есть = 150]\n<:low:1226398300790325330>Коины ``50`` <a:coin:1224788530006331412>\n<:low:1226398300790325330>Роль ``ошмёток майонеза`` <:big_blush:1172407318747549736> [если есть = 50]\n\nСтоимость кейса — **499** <a:coin:1224788530006331412>"
        )
        embed.set_author(name="Кейс \"Mafia Starter\"", icon_url="https://message.style/cdn/images/947161c106d0d59da9b39df3a184cc4d03f4e210d0ee0e0f59dbc349861637a5.png")
        embed.set_image(url="https://media.discordapp.net/attachments/1222939398979457114/1226422387499597824/ezgif-1-a8ae87fa2a.gif?ex=6624b5db&is=661240db&hm=964587bd4dd7519596d6ff050eed75cf861fa626e747ca8e4aaeb810903aba04&=")



        v = BackBtn(interaction)
        opcase = discord.ui.Button(label="Купить кейс за 499 🪙", style=discord.ButtonStyle.primary, emoji="📦", custom_id='opencase')
        opcase.callback = self.opcase
        v.add_item(opcase)
        await interaction.respond(embed=embed, view=v, ephemeral=True, delete_after=60)
        


    async def opcase(self, interaction: discord.Interaction):

        bal = await get_bal(interaction.user.id)
        if bal >= 499:
            await minus_bal(interaction.user.id, 499)

            
            we = discord.Embed()
            


            c = random.random()

            if c < 0.227:
                im = "https://cdn.discordapp.com/attachments/1215669560640806912/1226895456076955719/6fdd265d1dea701d.png?ex=66266e6f&is=6613f96f&hm=00f01d4c8dfd712b7f38a17395fa096852fe089e79563a53bf2a183609f3a264&"

                role = discord.utils.get(interaction.guild.roles, id = ошмёток)
                if role in interaction.user.roles:

                    await plus_bal(interaction.user.id, 50)
                    
                    we.description = "Ты открыл кейс и **получил** `ошмёток майонеза`, но он у вас уже есть, вам начислена компенсация в размере 50 коинов"
                else:
                    await interaction.user.add_roles(role)
                    with open("./drop/ошмёток майонеза.png", "rb") as img:
                        img = discord.File(img)
                    we.description = "Ты открыл кейс и **получил** `ошмёток майонеза`"

            elif c < 0.227 + 0.2:
                im = "https://cdn.discordapp.com/attachments/1215669560640806912/1226895438616068167/50_.png?ex=66266e6b&is=6613f96b&hm=76cc80c0574f900914b4f6977475bc1b0ced9cf4689383575f9fce4162b94fd4&"
                
                await plus_bal(interaction.user.id, 50)
                with open("./drop/+50 коинов.png", "rb") as img:
                    img = discord.File(img)
                we.description = "Ты открыл кейс и **получил** `50 коинов`"


            elif c < 0.227 + 0.2 + 0.2:
                im = "https://cdn.discordapp.com/attachments/1215669560640806912/1226895439756918844/25.png?ex=66266e6b&is=6613f96b&hm=cb010e65ae31314d9b4aac738fcaa3985988fb605f3ab1ecad6e6b7251c0c257&"

                with open("./drop/+скидка 25.png", "rb") as img:
                    img = discord.File(img)
                we.description = "Ты открыл кейс и **получил** `скидку на роль Мафия`"

            elif c < 0.227 + 0.2 + 0.2 + 0.15:
                im = "https://cdn.discordapp.com/attachments/1215669560640806912/1226895433998274692/1_.png?ex=66266e6a&is=6613f96a&hm=d4d0d9465d7261f8d14edee2f0713c1263e1297b88faa7c9d44037d3e48589d3&"

                if await get_lock(interaction.user.id) < 1:
                    with open("./drop/+1 уникальный фон для бита.png", "rb") as img:
                        img = discord.File(img)
                    await unlockback1(interaction.user.id)
                    we.description = "Вы разблокировали `крутой фон` для загрузки бита"
                else:
                    with open("./drop/+1 уникальный фон для бита.png", "rb") as img:
                        img = discord.File(img)
                    await plus_bal(interaction.user.id, 1000)
                    we.description = "Ты открыл кейс и **получил** `крутой фон`, но он у вас уже есть. Вам начислена компенсация в количестве 1 000 коинов"

            elif c < 0.227 + 0.2 + 0.2 + 0.15 + 0.05:
                im = "https://media.discordapp.net/attachments/1222939398979457114/1227018988966641786/200_.png?ex=6626e17b&is=66146c7b&hm=141d0d02a00edda6330342c77f8b200e56e513ea89975ed0c0f61529bab365b4&=&"

                with open("./drop/+200 коинов.png", "rb") as img:
                        img = discord.File(img)
                await plus_bal(interaction.user.id, 499)
                we.description = "Ты открыл кейс и **получил** `499 коинов`"

            elif c < 0.227 + 0.2 + 0.2 + 0.15 + 0.05 + 0.05:
                im = "https://cdn.discordapp.com/attachments/1215669560640806912/1226895440667217940/blessed.png?ex=66266e6b&is=6613f96b&hm=e2df2abd6e95cace5dad1dbf3723ef8a257e1e611bb5709e088412a62b26458c&"

                role = discord.utils.get(interaction.guild.roles, id = блессед)
                if role in interaction.user.roles:
                    await plus_bal(interaction.user.id, 150)
                    with open("./drop/blessed.png", "rb") as img:
                        img = discord.File(img)
                    we.description = "Ты открыл кейс и **получил** `BLESSED`, но он у вас уже есть, вам начислена компенсация в количестве 150 коинов"
                else:
                    with open("./drop/blessed.png", "rb") as img:
                        img = discord.File(img)
                    await interaction.user.add_roles(role)
                    we.description = "Ты открыл кейс и **получил** `BLESSED`"

            elif c < 0.227 + 0.2 + 0.2 + 0.15 + 0.05 + 0.05 + 0.05:
                im = "https://cdn.discordapp.com/attachments/1215669560640806912/1226895441510269101/gang.png?ex=66266e6b&is=6613f96b&hm=3a2dbd1fcc43f943745147f2f33d2044ca2d093145c1edb86d5cba7bbafa0ff1&"

                role = discord.utils.get(interaction.guild.roles, id = гэньг)
                if role in interaction.user.roles:
                    with open("./drop/gang.png", "rb") as img:
                        img = discord.File(img)
                    await plus_bal(interaction.user.id, 150)
                    we.description = "Ты открыл кейс и **получил** `gang`, но он у вас уже есть, вам начислена компенсация в количестве 150 коинов"
                else:
                    with open("./drop/gang.png", "rb") as img:
                        img = discord.File(img)
                    await interaction.user.add_roles(role)
                    we.description = "Ты открыл кейс и **получил** `gang`"

            elif c < 0.227 + 0.2 + 0.2 + 0.15 + 0.05 + 0.05 + 0.05 + 0.05:
                im = "https://media.discordapp.net/attachments/1222939398979457114/1227021555406606496/3333_.png?ex=6626e3df&is=66146edf&hm=9766aab9cafacf641d5a0d8376fbc340fa8f4783ba0115794fccdd000e1e088a&=&format=webp&quality=lossless"

                role = discord.utils.get(interaction.guild.roles, id = четыре1)
                if role in interaction.user.roles:
                    with open("./drop/1111.png", "rb") as img:
                        img = discord.File(img)
                    await plus_bal(interaction.user.id, 1000)
                    we.description = "Ты открыл кейс и **получил** `𝟛𝟛𝟛𝟛𝟛`, но он у вас уже есть, вам начислена компенсация в количестве 1 000 коинов"
                else:
                    with open("./drop/1111.png", "rb") as img:
                        img = discord.File(img)
                    await interaction.user.add_roles(role)
                    we.description = "Ты открыл кейс и **получил** `𝟛𝟛𝟛𝟛𝟛`"

            elif c < 0.227 + 0.2 + 0.2 + 0.15 + 0.05 + 0.05 + 0.05 + 0.05 + 0.02:
                im = "https://media.discordapp.net/attachments/1222939398979457114/1227020225896120380/1500.png?ex=6626e2a2&is=66146da2&hm=fd5aa5d434abf944d245a002cab03f3350ecfd665055e751f54d68f1231e4977&=&format=webp&quality=lossless"

                with open("./drop/+500 коинов.png", "rb") as img:
                    img = discord.File(img)
                await plus_bal(interaction.user.id, 1500)
                we.description = "Ты открыл кейс и **получил** `1 500 коинов`"

            elif c < 0.227 + 0.2 + 0.2 + 0.15 + 0.05 + 0.05 + 0.05 + 0.05 + 0.02 + 0.001:
                im = "https://cdn.discordapp.com/attachments/1215669560640806912/1226895441052958800/discord_nitro.png?ex=66266e6b&is=6613f96b&hm=2823c057c426cc2576b3e290bcc310d248f8d9a0820fb78fd513c06e89cfc481&"

                with open("./drop/discord nitro.png", "rb") as img:
                    img = discord.File(img)
                user = await self.bot.fetch_user(david_id)
                await user.send(f'{interaction.user.mention} выбил с кейса дс нитро')
                we.description = "Ты открыл кейс и **получил** `Discord Nitro (Месяц)`, с вами свяжутся"

            elif c < 0.227 + 0.2 + 0.2 + 0.15 + 0.05 + 0.05 + 0.05 + 0.05 + 0.02 + 0.001 + 0.001:
                im = "https://cdn.discordapp.com/attachments/1215669560640806912/1226895456571752519/telegram_premium.png?ex=66266e6f&is=6613f96f&hm=c57d9a927e548abbdac96986b8d4257f121ae034b0902cea15e256f2de2e72ba&"

                with open("./drop/telegram premium.png", "rb") as img:
                    img = discord.File(img)
                user = await self.bot.fetch_user(david_id)
                await user.send(f'{interaction.user.mention} выбил с кейса тг прем')
                we.description = "Ты открыл кейс и **получил** `Telegram Premium (Месяц)`, с вами свяжутся"

            elif c <= 0.227 + 0.2 + 0.2 + 0.15 + 0.05 + 0.05 + 0.05 + 0.05 + 0.02 + 0.001 + 0.001 + 0.001:
                im = "https://cdn.discordapp.com/attachments/1215669560640806912/1226895433499148418/spotify_premium.png?ex=66266e69&is=6613f969&hm=9d27713722f7f9242e38948f2cd9d3d2010e8d717f30b5919fa5c39d9b45315e&"

                with open("./drop/spotify premium.png", "rb") as img:
                    img = discord.File(img)
                user = await self.bot.fetch_user(david_id)
                await user.send(f'{interaction.user.mention} выбил с кейса спотик премиум')
                we.description = "Ты открыл кейс и **получил** `Spotify Individual (месяц)`, с вами свяжутся"

            
            we.set_image(url=im)
            we.set_author(name="Поздравляем!", icon_url="https://message.style/cdn/images/947161c106d0d59da9b39df3a184cc4d03f4e210d0ee0e0f59dbc349861637a5.png")
            we.set_footer(text="Mafia Boss", icon_url="https://message.style/cdn/images/3e620ca9c6a4a672451edb2834c58c8b4d8682f3665fc28dd72bb8d142c65bba.png")


            ve = BackBtn(interaction)
            it = discord.ui.Button(label="Открыть ещё один за 499 🪙", style=discord.ButtonStyle.primary, emoji="📦", custom_id='opcase2')
            it.callback = self.opcase
            ve.add_item(it)
            
            
            await interaction.respond(embed=we, view=ve, ephemeral=True, delete_after=60)

        else:
            await interaction.respond("Недостаточно средств для покупки", ephemeral=True, delete_after=60)

        



    #@discord.ui.button(label="Роли", style=discord.ButtonStyle.primary, emoji="rainbowsheep")
    async def showroles(self, interaction: discord.Interaction):
        await interaction.response.defer(invisible=False, ephemeral=True)
        
        with open('roles.json', 'r', encoding='utf-8') as file:
            roles_data = json.load(file)
        emojis = {}
        for role, role_data in roles_data.items():
            emoji = await interaction.guild.fetch_emoji(role_data['emoji'])
            emojis[role] = emoji
        current_page_roles = dict(list(roles_data.items())[0:5])
        role_select = RoleSelect(current_page_roles, emojis, self.bot, interaction)

        paginator = Paginator(roles_data, emojis, self.bot, interaction)
        paginator.add_item(role_select)
        embed = discord.Embed(
            description="Некоторые роли из магазина **со временем исчезнут и никогда больше не появятся**. Они помечены звездочкой* и лимитированы\n\n- <:pngwing:1172688623691386981> ``𝐅𝐋 𝐒𝐓𝐔𝐃𝐈𝐎`` — 111 <a:coin:1224788530006331412>\n- <:big_blush:1172407318747549736> ``ошмёток майонеза`` — 250 <a:coin:1224788530006331412>\n-  <:4571heartdamage3:1225155350307667998> ``ʟᴏS̶vᴇʀ`` — 333 <a:coin:1224788530006331412>\n-  <a:uzigold:1174188153226137630> ``𝐭𝐫𝐮𝐬𝐭𝐞𝐝`` — 600 <a:coin:1224788530006331412>\n-  <a:4955uziyee:1161072604380151968> ``Верный*`` — 600 <a:coin:1224788530006331412>\n-   <:bless:1225154820168486963> ``ʙʟᴇꜱꜱᴇᴅ`` — 1 777 <a:coin:1224788530006331412>"
        )
        embed.set_author(name="Роли (страница 1)", icon_url="https://message.style/cdn/images/947161c106d0d59da9b39df3a184cc4d03f4e210d0ee0e0f59dbc349861637a5.png")
        embed.set_image(url="https://message.style/cdn/images/ce7d6b623e9867f0bd7ee94a8f1fd6322e6db426bbc0f3bb834fcd2d5e4f60f4.png")
        embed.add_field(value="<:leftarrow_2b05fe0f:1226797088608878592> Предыдущая страница", inline=True, name=" ")
        embed.add_field(value="<:rightarrow_27a1fe0f:1226797078437691443> Следующая страница", inline=True, name=" ")
        embed.set_footer(text="Mafia Boss", icon_url="https://message.style/cdn/images/3e620ca9c6a4a672451edb2834c58c8b4d8682f3665fc28dd72bb8d142c65bba.png")
        
        print(f'[cyan] {interaction.user}')
        #btns = RoleSelect2(emojis, self.bot, interaction)
        await interaction.respond(embed=embed, view=paginator, ephemeral=True, delete_after=120)

    
    #@discord.ui.button(label="Подписки на сервисы", style=discord.ButtonStyle.primary, emoji="2320spotify")
    async def showosubs(self, interaction: discord.Interaction):


        with open('sub.json', 'r', encoding='utf-8') as file:
            roles_data = json.load(file)
        emojis = {}
        for role, role_data in roles_data.items():
            emoji = await interaction.guild.fetch_emoji(role_data['emoji'])
            emojis[role] = emoji

        btns = SubSelect2(emojis=emojis, bot=self.bot, ctx=interaction)

        e = discord.Embed(description="Кто-то решил разорить Давида Пиццу и это правильно. Предлагаю забрать у него все деньги. Выбери сервис и **обменяй коины на месячную подписку!**\n\n- <:2320spotify:1225150214134956083> Spotify Individual —    29 999 <a:coin:1224788530006331412>\n- <:4929discord:1225164976675618926> Discord Nitro — 34 999 <a:coin:1224788530006331412>\n- <:9739telegram:1225164964801810523> Telegram Premium — 29 999 <a:coin:1224788530006331412>",
                            color=3158064)
        e.set_author(name="Подписки", icon_url="https://message.style/cdn/images/947161c106d0d59da9b39df3a184cc4d03f4e210d0ee0e0f59dbc349861637a5.png")
        e.set_image(url="https://media.discordapp.net/attachments/1222939398979457114/1227012074128019556/Component_23.png?ex=6626db0b&is=6614660b&hm=1f8cfb88e4b01f1c37cec6d0c152af593c1494bf0c15b4376773c2a446eac0c1&=&format=webp&quality=lossless")
        e.set_footer(text="Mafia #1", icon_url="https://message.style/cdn/images/3e620ca9c6a4a672451edb2834c58c8b4d8682f3665fc28dd72bb8d142c65bba.png")


        await interaction.response.send_message(embed=e, view=btns, ephemeral=True, delete_after=60)


    #@discord.ui.button(label="Закрыть", style=discord.ButtonStyle.gray, emoji='❎')
    async def close(self, interaction: discord.Interaction):

        await self.g.delete_original_response()






class ShopBtn(discord.ui.View):

    def __init__(self, bot: discord.Bot, emoj):
        super().__init__()
        self.emoj = emoj
        self.bot = bot
        self.clear_items()
        it = discord.ui.Button(label="Посмотреть товары", style=discord.ButtonStyle.primary, emoji="🎁", custom_id='showshop1')
        it.callback = self.showshop
        self.add_item(it)
        it2 = discord.ui.Button(label="Мой баланс", style=discord.ButtonStyle.success, emoji=emoj, custom_id='viewbal2')
        it2.callback = self.viewbal
        self.add_item(it2)
        self.it3 = discord.ui.Button(label="Мафия", style=discord.ButtonStyle.danger, emoji="👑", custom_id='premium2')
        self.it3.callback = self.premium

    

    async def on_timeout(self):
        
        channel = self.bot.get_channel(shopid)
        if channel:

            embed = discord.Embed(color=3158064,                 
                description="Магазинчик 24/7. Трать коины с умом! Я бы, лично, взял роль <a:8494potatotriggered:1225155091456200874> 𝕸𝖆𝖋𝖎𝖆 𝕭𝖔𝖘𝖘, потому что я люблю себя. В любом случае, держи подсказки, как быстрее заработать коины!\n\n- **<:ok:1172743098779050037> Оставляй комментарии другим работам**\n> За каждый комментарий, который ТЫ напишешь - +2 <a:coin:1224788530006331412> коина\n- **<:ok:1172743098779050037> Получай лайки**\n> За каждый лайк, который ТЕБЕ поставят - +5 <a:coin:1224788530006331412> коинов\n- **<:ok:1172743098779050037> Приглашай друзей**\n> За каждого приглашенного друга на сервер - +50 <a:coin:1224788530006331412> коинов мгновенно")

            embed.set_author(name="Магазин", url="https://message.style/cdn/images/947161c106d0d59da9b39df3a184cc4d03f4e210d0ee0e0f59dbc349861637a5.png")
            embed.set_image(url="https://media.discordapp.net/attachments/1222939398979457114/1227010695917207582/Component_22_2.png?ex=6626d9c2&is=661464c2&hm=849074f80d42c0029c13231b2c374d7850d46252effbac5450acdbdde44ec1f5&=&format=webp&quality=lossless")


    
            # Создаем новое сообщение с кнопкой
            view = ShopBtn(self.bot, self.emoj)
            view.timeout = None
            view.add_item(discord.ui.Button(label="Личный кабинет", style=discord.ButtonStyle.link, url=mainchannel, emoji="💻"))
            view.add_item(self.it3)
            await channel.send(embed=embed, view=view)



    #@discord.ui.button(label="Посмотреть товары", style=discord.ButtonStyle.primary, emoji="🎁", custom_id='showshop1')
    async def showshop(self, interaction: discord.Interaction):
        
        em = await interaction.guild.fetch_emoji(1174185134384222238)
        em2 = await interaction.guild.fetch_emoji(1225150214134956083)
        btns = CatBtn(interaction, em, em2, interaction, self.bot)

        embed = discord.Embed(description="Выбери интересующую тебя **категорию**:")
        embed.set_author(name="Товары", icon_url="https://message.style/cdn/images/947161c106d0d59da9b39df3a184cc4d03f4e210d0ee0e0f59dbc349861637a5.png")





        await interaction.response.send_message(embed=embed, view=btns, ephemeral=True, delete_after=60)
        


    #@discord.ui.button(label="Мой баланс", style=discord.ButtonStyle.success, emoji="📊", custom_id='viewbal2')
    async def viewbal(self, interaction: discord.Interaction):
        if await check_user(interaction.user.id):
            bal = await get_bal(interaction.user.id)
            like = await get_like(interaction.user.id)
            plike = await get_plike(interaction.user.id)
            await interaction.response.send_message(f"Ваш баланс: `{bal}`🪙\nВаши лайки: `{like}`👍\nВы поставили лайков: `{plike}`✅", ephemeral=True, delete_after=60)
        else:
            await reg_user(interaction.user.id)
            await interaction.response.send_message(f"Ваш баланс: `0`🪙", ephemeral=True, delete_after=60)
        


    #@discord.ui.button(label="Мафия", style=discord.ButtonStyle.success, emoji="👑", custom_id='premium2')
    async def premium(self, interaction: discord.Interaction):
         
        
        embed = discord.Embed(description="Проект уточки Mafia Boss сделан, в первую очередь, чтобы **добавить в битмейкерское коммьюнити что-то новое и интересное**\n\n**Мафия** <:9388redownerbadge:1226660683706400909> - это просто способ показать нам свою любовь и дать понять что это интересно и нужно развивать дальше. Ну и, конечно, на эту любовь мы ответим взаимностью:\n\n- **Снятие лимита в загрузке битов**\n> Бот бесплатный, это правда, но для бесплатного плана существует лимит - 2 бита в день. С ролью <:9388redownerbadge:1226660683706400909> **мафия** количество битов в день увеличивается до ∞ :)\n- **Разблокируются все фоны в личном кабинете**\n> Ты сможешь выбрать любой из предоставленных фонов при загрузке бита. Список фонов будет обновляться. Ты будешь иметь доступ ко всем будущим фонам в том числе\n- **Доступ ко всем каналам для битмейкеров**\n> Человек с ролью <:9388redownerbadge:1226660683706400909> **мафия** получает доступ к таким каналам как: <#1174054958941884467>, <#1174055020610732202>, <#1174055213624213505>, <#1174055325532426250>, <#1174055424090185748><#1174055534803034162>, <#1174055598594195466>\n- **Выделение среди всех участников**\n> Роль <:9388redownerbadge:1226660683706400909> **мафия** красиво выделяется в списке участников сервера наверху")
        embed.set_author(name="Мафия 👑", icon_url="https://message.style/cdn/images/947161c106d0d59da9b39df3a184cc4d03f4e210d0ee0e0f59dbc349861637a5.png")
        embed.set_image(url="https://media.discordapp.net/attachments/1222939398979457114/1226638284118294638/ezgif-5-fdc985fb45.gif?ex=66257eec&is=661309ec&hm=d1a7fe638eff8fc7bb63808b9815e37db6ab0e67eb0f8dddc02062f61db80daf&=")
        embed.set_footer(text="Mafia Boss", icon_url="https://message.style/cdn/images/3e620ca9c6a4a672451edb2834c58c8b4d8682f3665fc28dd72bb8d142c65bba.png")



        v = BackBtn(interaction)
        emoji = await interaction.guild.fetch_emoji(1172274058101006407)
        v.add_item(discord.ui.Button(label='Оформить "Мафия"', style=discord.ButtonStyle.link, url="https://boosty.to/flmafia", emoji=emoji))

        await interaction.response.send_message(embed=embed, ephemeral=True, view=v, delete_after=60)




class BackBtn(discord.ui.View):
    def __init__(self, g):
        super().__init__()
        self.g = g
    
    async def on_timeout(self) -> None:
        return await super().on_timeout()

    
    @discord.ui.button(label="Закрыть", style=discord.ButtonStyle.gray, emoji='❎', custom_id='close1')
    async def close(self, button, interaction: discord.Interaction):

        await self.g.delete_original_response()

















class AcceptBtn(discord.ui.View):

    def __init__(self, bot: discord.Bot, price, tovar, isrole, ctx: discord.Interaction, rid: int = None):
        super().__init__()
        self.ctx = ctx
        self.bot = bot
        self.price = price
        self.tovar = tovar
        self.isrole = isrole
        self.rid = rid
    

    @discord.ui.button(label="Подтвердить", style=discord.ButtonStyle.primary, emoji="✅")
    async def acceptshop(self, button, interaction: discord.Interaction):
        if await minus_bal(interaction.user.id, self.price):
            if self.isrole:
                
                guild = interaction.guild
                role = guild.get_role(int(self.rid))
                await interaction.user.add_roles(role)
                await self.ctx.delete_original_response()
                await interaction.response.send_message(f"✅  Оплата прошла успешно", ephemeral=True, delete_after=60)
            
            else:
                message = f"{interaction.user.mention} купил {self.tovar}"
                user = await self.bot.fetch_user(david_id)
                await user.send(message)
                await self.ctx.delete_original_response()
                await interaction.response.send_message(f"✅  Оплата прошла успешно, в ближайшее время с тобой свяжутся", ephemeral=True, delete_after=60)
                
        
        else:
            await self.ctx.delete_original_response()
            await interaction.response.send_message("⛔️  У вас недостаточно средств", ephemeral=True, delete_after=60)

    @discord.ui.button(label="Отмена", style=discord.ButtonStyle.danger, emoji="⚠️")
    async def cancelshop(self, button, interaction: discord.Interaction):

        await interaction.respond("✅  Ты отменил покупку", ephemeral=True, delete_after=60)